package ps.man.water;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import java.util.Locale;

public class TimerService extends Service {
    public static final String START="START", PAUSE="PAUSE", RESUME="RESUME", STOP="STOP";
    private static final String CHANNEL="water_timer";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long left;
    private boolean paused, warned90, warned60;
    private String person = "مشترك";
    private PowerManager.WakeLock wakeLock;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!paused) {
                left = Math.max(0, left - 1);
                if (left == 90 && !warned90) { warned90=true; alarm(ToneGenerator.TONE_PROP_BEEP, "تبقى دقيقة ونصف"); }
                if (left == 60 && !warned60) { warned60=true; alarm(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, "خطر: تبقت دقيقة"); }
                if (left == 0) { alarm(ToneGenerator.TONE_CDMA_HIGH_L, "انتهى الوقت"); finishTimer(); return; }
                notifyNow();
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "عداد الغاطس", NotificationManager.IMPORTANCE_HIGH);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
        PowerManager power = (PowerManager)getSystemService(POWER_SERVICE);
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MANWater:Timer");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (START.equals(action)) {
            person = intent.getStringExtra("name"); if (person == null || person.isEmpty()) person="مشترك";
            left = intent.getIntExtra("seconds", 0); paused=false; warned90=false; warned60=false;
            if (!wakeLock.isHeld()) wakeLock.acquire(43_200_000L);
            startForeground(7, notification("العداد يعمل")); handler.removeCallbacks(tick); handler.postDelayed(tick,1000);
        } else if (PAUSE.equals(action)) { paused=true; notifyNow(); }
        else if (RESUME.equals(action)) { paused=false; notifyNow(); }
        else if (STOP.equals(action)) finishTimer();
        return START_STICKY;
    }

    private Notification notification(String text) {
        PendingIntent pending = PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(person+" — "+format(left)).setContentText(text).setContentIntent(pending)
                .setOngoing(left>0).setPriority(Notification.PRIORITY_MAX).setCategory(Notification.CATEGORY_ALARM).setOnlyAlertOnce(true).build();
    }

    private void notifyNow() { ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7,notification(paused?"متوقف مؤقتًا":"العداد يعمل")); }
    private void alarm(int tone,String text) {
        Notification n = new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(person).setContentText(text).setPriority(Notification.PRIORITY_MAX).setCategory(Notification.CATEGORY_ALARM).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(8,n);
        AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE);
        int previous=audio.getStreamVolume(AudioManager.STREAM_ALARM);
        int maximum=audio.getStreamMaxVolume(AudioManager.STREAM_ALARM);
        audio.setStreamVolume(AudioManager.STREAM_ALARM,maximum,0);
        ToneGenerator generator = new ToneGenerator(AudioManager.STREAM_ALARM,100);
        generator.startTone(tone,5000);
        handler.postDelayed(()->{generator.stopTone();generator.release();audio.setStreamVolume(AudioManager.STREAM_ALARM,previous,0);},5100);
    }
    private void finishTimer() { handler.removeCallbacks(tick); left=0; notifyNow(); if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release(); stopForeground(STOP_FOREGROUND_DETACH); stopSelf(); }
    private String format(long seconds) { return String.format(Locale.US,"%02d:%02d:%02d",seconds/3600,(seconds%3600)/60,seconds%60); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
