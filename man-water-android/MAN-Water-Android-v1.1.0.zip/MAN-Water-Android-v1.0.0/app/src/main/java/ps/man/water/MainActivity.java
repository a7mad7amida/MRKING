package ps.man.water;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private static final String TIMER_BRIDGE =
            "(function(){if(window.__manAndroidBridge)return;"+
            "if(!window.AndroidTimer||!window.getManTimerState||!window.toggleRun||!window.togglePause)return;"+
            "window.__manAndroidBridge=true;"+
            "var webRun=window.toggleRun,webPause=window.togglePause;"+
            "window.toggleRun=async function(){var before=window.getManTimerState();await webRun();var after=window.getManTimerState();"+
            "if(!before.run&&after.run)window.AndroidTimer.start(after.run.subscriber_name||'مشترك',after.preset*60);"+
            "else if(before.run&&!after.run)window.AndroidTimer.stop();};"+
            "window.togglePause=async function(){var before=window.getManTimerState();await webPause();var after=window.getManTimerState();"+
            "if(!before.paused&&after.paused)window.AndroidTimer.pause();else if(before.paused&&!after.paused)window.AndroidTimer.resume();};"+
            "var settings=document.getElementById('settingsTab');if(settings&&!document.getElementById('androidSoundPicker')){"+
            "var box=document.createElement('div');box.id='androidSoundPicker';box.style.cssText='margin:14px;padding:16px;border-radius:16px;background:#eef7ff;border:1px solid #b9dcff;text-align:center';"+
            "box.innerHTML='<b style=\"display:block;margin-bottom:9px\">🔔 نغمة تنبيهات العداد</b><button style=\"border:0;border-radius:12px;padding:11px 18px;background:#1677ff;color:white;font-weight:bold\" onclick=\"AndroidTimer.chooseSound()\">اختيار نغمة من الهاتف</button>';settings.prepend(box);}"+
            "})();";

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 30);
        }
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.addJavascriptInterface(new TimerBridge(), "AndroidTimer");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("man.ps".equals(uri.getHost())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(TIMER_BRIDGE, null);
                injectEnhancements(view);
                view.postDelayed(() -> view.evaluateJavascript(TIMER_BRIDGE, null), 1500);
                view.postDelayed(() -> injectEnhancements(view), 1700);
                view.postDelayed(() -> view.evaluateJavascript(TIMER_BRIDGE, null), 4000);
            }
        });
        web.loadUrl("https://man.ps/water");
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    private class TimerBridge {
        @JavascriptInterface public void start(String name, int seconds) { send(TimerService.START, name, seconds); }
        @JavascriptInterface public void pause() { send(TimerService.PAUSE, "", 0); }
        @JavascriptInterface public void resume() { send(TimerService.RESUME, "", 0); }
        @JavascriptInterface public void stop() { send(TimerService.STOP, "", 0); }
        @JavascriptInterface public void chooseSound() { runOnUiThread(MainActivity.this::openSoundPicker); }
        @JavascriptInterface public void setAlertMode(String mode) { getSharedPreferences("man_water",MODE_PRIVATE).edit().putString("alert_mode",mode).apply(); }
        @JavascriptInterface public void testAlert() { send(TimerService.TEST,"تجربة التنبيه",1); }
        private void send(String action, String name, int seconds) {
            Intent intent = new Intent(MainActivity.this, TimerService.class)
                    .setAction(action).putExtra("name", name).putExtra("seconds", seconds);
            if (TimerService.START.equals(action)||TimerService.TEST.equals(action)) startForegroundService(intent); else startService(intent);
        }
    }

    private void injectEnhancements(WebView view) {
        try(InputStream input=getAssets().open("worker-tools.js")) {
            String script=new String(input.readAllBytes(),StandardCharsets.UTF_8);
            view.evaluateJavascript(script,null);
        } catch(Exception ignored) { }
    }

    private void openSoundPicker() {
        Intent picker=new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        picker.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,RingtoneManager.TYPE_NOTIFICATION);
        picker.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT,false);
        picker.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT,true);
        startActivityForResult(picker,91);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==91&&resultCode==RESULT_OK&&data!=null){
            Uri selected=data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            if(selected!=null)getSharedPreferences("man_water",MODE_PRIVATE).edit().putString("alert_uri",selected.toString()).apply();
        }
    }
}
