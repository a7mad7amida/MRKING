(function installWorkerTools(){
  if(window.__manWorkerTools)return;
  if(!window.AndroidTimer||!window.getManTimerState||!window.toggleRun){setTimeout(installWorkerTools,700);return;}
  window.__manWorkerTools=true;
  const root=document.getElementById('timerTab'); if(!root)return;
  const style=document.createElement('style');
  style.textContent='.manNativeCard{margin:14px 0;padding:16px;border:1px solid #cfe3f8;border-radius:18px;background:#f7fbff}.manNativeCard h3{margin:0 0 10px}.manNativeGrid{display:grid;grid-template-columns:1fr 110px auto;gap:8px}.manNativeCard input,.manNativeCard select{width:100%;box-sizing:border-box;padding:10px;border:1px solid #ccd8e5;border-radius:10px}.manNativeCard button{border:0;border-radius:10px;padding:10px 12px;background:#1677ff;color:#fff;font-weight:700}.manQueueRow{display:grid;grid-template-columns:1fr auto auto auto;gap:7px;align-items:center;padding:9px 0;border-bottom:1px solid #e5edf5}.manQueueRow button{padding:7px 9px}.manGap{padding:12px;margin-top:10px;border-radius:12px;background:#fff3cd;color:#7a5400;text-align:center;font-weight:bold}';document.head.appendChild(style);
  const queueCard=document.createElement('section');queueCard.className='manNativeCard';queueCard.innerHTML='<h3>قائمة انتظار المشتركين</h3><div class="manNativeGrid"><input id="manQueueName" placeholder="اسم المشترك"><input id="manQueueMinutes" type="number" min="1" value="10" placeholder="الدقائق"><button id="manQueueAdd">إضافة</button></div><div id="manQueueList"></div><div id="manGap" class="manGap" hidden></div>';
  const alertCard=document.createElement('section');alertCard.className='manNativeCard';alertCard.innerHTML='<h3>🔔 إعدادات تنبيه العامل</h3><div class="manNativeGrid" style="grid-template-columns:1fr auto auto"><select id="manAlertMode"><option value="popup_vibrate">منبثق + أيقونة + اهتزاز</option><option value="popup">منبثق + أيقونة</option><option value="icon">أيقونة بجانب الساعة فقط</option></select><button id="manPickSound">اختيار النغمة</button><button id="manTestSound">تجربة</button></div>';
  root.append(queueCard,alertCard);
  let queue=[];try{queue=JSON.parse(localStorage.getItem('man_water_queue')||'[]')}catch(e){}
  const save=()=>{localStorage.setItem('man_water_queue',JSON.stringify(queue));render()};
  function render(){manQueueList.innerHTML=queue.map((q,i)=>'<div class="manQueueRow"><span><b>'+escapeHtml(q.name)+'</b> — '+q.minutes+' دقيقة</span><button onclick="manQueueUp('+i+')">↑</button><button onclick="manQueueEdit('+i+')">تعديل</button><button style="background:#c63737" onclick="manQueueDelete('+i+')">حذف</button></div>').join('')||'<small>لا يوجد مشتركون في الانتظار</small>'}
  const escapeHtml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  manQueueAdd.onclick=()=>{let name=manQueueName.value.trim(),minutes=+manQueueMinutes.value;if(!name||minutes<1)return alert('أدخل اسم المشترك والوقت');queue.push({name,minutes});manQueueName.value='';save()};
  window.manQueueDelete=i=>{queue.splice(i,1);save()};window.manQueueUp=i=>{if(i>0)[queue[i-1],queue[i]]=[queue[i],queue[i-1]];save()};window.manQueueEdit=i=>{let name=prompt('اسم المشترك',queue[i].name),minutes=+prompt('الوقت بالدقائق',queue[i].minutes);if(name&&minutes>0){queue[i]={name,minutes};save()}};
  manAlertMode.onchange=()=>AndroidTimer.setAlertMode(manAlertMode.value);manPickSound.onclick=()=>AndroidTimer.chooseSound();manTestSound.onclick=()=>AndroidTimer.testAlert();
  const priorToggle=window.toggleRun;let transition=false;
  window.toggleRun=async function(){let before=getManTimerState();await priorToggle();let after=getManTimerState();if(!transition&&before.run&&!after.run&&queue.length)startGap()};
  function startGap(){transition=true;let seconds=10;manGap.hidden=false;manGap.textContent='حوّل شِبر المياه — تشغيل المشترك التالي خلال '+seconds+' ثوانٍ';let interval=setInterval(async()=>{seconds--;manGap.textContent='حوّل شِبر المياه — تشغيل المشترك التالي خلال '+seconds+' ثوانٍ';if(seconds<=0){clearInterval(interval);let next=queue.shift();save();manGap.hidden=true;subscriberName.value=next.name;customMinutes.value=next.minutes;if(window.customTime)customTime(next.minutes);transition=false;await window.toggleRun()}},1000)}
  render();
})();
