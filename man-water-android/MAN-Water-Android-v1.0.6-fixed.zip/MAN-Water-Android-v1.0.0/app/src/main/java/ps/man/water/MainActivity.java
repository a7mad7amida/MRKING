package ps.man.water;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private static final String TIMER_BRIDGE =
            "(function(){if(window.__manAndroidBridge)return;"+
            "if(!window.AndroidTimer||!window.getManTimerState||!window.toggleRun||!window.togglePause)return;"+
            "window.__manAndroidBridge=true;"+
            "var webRun=window.toggleRun,webPause=window.togglePause;"+
            "window.toggleRun=async function(){var before=window.getManTimerState();await webRun();var after=window.getManTimerState();"+
            "if(!before.run&&after.run)window.AndroidTimer.start(after.run.subscriber_name||'مشترك',after.preset*60);"+
            "else if(before.run&&!after.run)window.AndroidTimer.stop();};"+
            "window.togglePause=async function(){var before=window.getManTimerState();await webPause();var after=window.getManTimerState();"+
            "if(!before.paused&&after.paused)window.AndroidTimer.pause();else if(before.paused&&!after.paused)window.AndroidTimer.resume();};"+
            "})();";

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 30);
        }
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.addJavascriptInterface(new TimerBridge(), "AndroidTimer");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("man.ps".equals(uri.getHost())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(TIMER_BRIDGE, null);
                view.postDelayed(() -> view.evaluateJavascript(TIMER_BRIDGE, null), 1500);
                view.postDelayed(() -> view.evaluateJavascript(TIMER_BRIDGE, null), 4000);
            }
        });
        web.loadUrl("https://man.ps/water");
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    private class TimerBridge {
        @JavascriptInterface public void start(String name, int seconds) { send(TimerService.START, name, seconds); }
        @JavascriptInterface public void pause() { send(TimerService.PAUSE, "", 0); }
        @JavascriptInterface public void resume() { send(TimerService.RESUME, "", 0); }
        @JavascriptInterface public void stop() { send(TimerService.STOP, "", 0); }
        private void send(String action, String name, int seconds) {
            Intent intent = new Intent(MainActivity.this, TimerService.class)
                    .setAction(action).putExtra("name", name).putExtra("seconds", seconds);
            if (TimerService.START.equals(action)) startForegroundService(intent); else startService(intent);
        }
    }
}
