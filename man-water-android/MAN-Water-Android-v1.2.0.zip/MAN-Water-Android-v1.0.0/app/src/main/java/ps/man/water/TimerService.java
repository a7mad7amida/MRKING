package ps.man.water;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import java.util.Locale;
import java.util.HashSet;
import org.json.JSONArray;
import org.json.JSONObject;

public class TimerService extends Service {
    public static final String START="START", PAUSE="PAUSE", RESUME="RESUME", STOP="STOP", TEST="TEST";
    private static final String CHANNEL="water_timer", ALERT_POPUP="water_alert_popup_v4", ALERT_VIBRATE="water_alert_vibrate_v4", ALERT_ICON="water_alert_icon_v4";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long left, planned;
    private boolean paused;
    private final HashSet<String> firedAlerts=new HashSet<>();
    private String person = "مشترك";
    private PowerManager.WakeLock wakeLock;
    private Ringtone alertRingtone;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!paused) {
                left = Math.max(0, left - 1);
                checkConfiguredAlerts();
                if (left == 0) { finishTimer(); return; }
                notifyNow();
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "عداد الغاطس", NotificationManager.IMPORTANCE_HIGH);
            NotificationChannel popup = new NotificationChannel(ALERT_POPUP, "تنبيه منبثق", NotificationManager.IMPORTANCE_HIGH); popup.enableVibration(false);
            NotificationChannel vibration = new NotificationChannel(ALERT_VIBRATE, "تنبيه منبثق واهتزاز", NotificationManager.IMPORTANCE_HIGH); vibration.enableVibration(true); vibration.setVibrationPattern(new long[]{0,300,150,300,150,500});
            NotificationChannel icon = new NotificationChannel(ALERT_ICON, "أيقونة فقط", NotificationManager.IMPORTANCE_LOW); icon.enableVibration(false);
            NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel); manager.createNotificationChannel(popup); manager.createNotificationChannel(vibration); manager.createNotificationChannel(icon);
        }
        PowerManager power = (PowerManager)getSystemService(POWER_SERVICE);
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MANWater:Timer");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (START.equals(action)) {
            person = intent.getStringExtra("name"); if (person == null || person.isEmpty()) person="مشترك";
            left = intent.getIntExtra("seconds", 0); planned=left; paused=false; firedAlerts.clear();
            if (!wakeLock.isHeld()) wakeLock.acquire(43_200_000L);
            startForeground(7, notification("العداد يعمل")); handler.removeCallbacks(tick); handler.postDelayed(tick,1000);
        } else if (PAUSE.equals(action)) { paused=true; notifyNow(); }
        else if (RESUME.equals(action)) { paused=false; notifyNow(); }
        else if (STOP.equals(action)) finishTimer();
        else if (TEST.equals(action)) { person="تجربة التنبيه";startForeground(7,notification("اختبار الإشعار"));alarm("هذه تجربة نغمة وإشعار العداد",5,"popup_vibrate");handler.postDelayed(this::finishTimer,5200); }
        return START_STICKY;
    }

    private Notification notification(String text) {
        PendingIntent pending = PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(person+" — "+format(left)).setContentText(text).setContentIntent(pending)
                .setOngoing(left>0).setPriority(Notification.PRIORITY_MAX).setCategory(Notification.CATEGORY_ALARM).setOnlyAlertOnce(true).build();
    }

    private void notifyNow() { ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7,notification(paused?"متوقف مؤقتًا":"العداد يعمل")); }
    private void checkConfiguredAlerts(){
        String defaults="[{\"before\":90,\"duration\":5,\"mode\":\"popup_vibrate\",\"label\":\"تبقى دقيقة ونصف\",\"enabled\":true},{\"before\":60,\"duration\":5,\"mode\":\"popup_vibrate\",\"label\":\"تبقت دقيقة واحدة\",\"enabled\":true},{\"before\":0,\"duration\":5,\"mode\":\"popup_vibrate\",\"label\":\"انتهى الوقت\",\"enabled\":true}]";
        try{JSONArray rules=new JSONArray(getSharedPreferences("man_water",MODE_PRIVATE).getString("alert_rules",defaults));for(int i=0;i<rules.length();i++){JSONObject rule=rules.getJSONObject(i);if(!rule.optBoolean("enabled",true))continue;int before=rule.optInt("before",0);String key=i+":"+before;if(left<=before&&(before==0||planned>=before)&&!firedAlerts.contains(key)){firedAlerts.add(key);alarm(rule.optString("label","تنبيه العداد"),Math.max(1,Math.min(30,rule.optInt("duration",5))),rule.optString("mode","popup_vibrate"));}}}catch(Exception ignored){}
    }
    private void alarm(String text,int duration,String configuredMode) {
        String mode=configuredMode==null||configuredMode.isEmpty()?getSharedPreferences("man_water",MODE_PRIVATE).getString("alert_mode","popup_vibrate"):configuredMode;
        String alertChannel="icon".equals(mode)?ALERT_ICON:("popup".equals(mode)?ALERT_POPUP:ALERT_VIBRATE);
        PendingIntent pending=PendingIntent.getActivity(this,2,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder builder = new Notification.Builder(this,alertChannel).setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(person).setContentText(text).setContentIntent(pending).setAutoCancel(true)
                .setPriority(Notification.PRIORITY_MAX).setCategory(Notification.CATEGORY_MESSAGE)
                .setTimeoutAfter(15000);
        if("popup_vibrate".equals(mode))builder.setDefaults(Notification.DEFAULT_VIBRATE);
        Notification n=builder.build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(8,n);
        AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE);
        int previous=audio.getStreamVolume(AudioManager.STREAM_NOTIFICATION);
        int maximum=audio.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION);
        audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION,maximum,0);
        try {
            if(alertRingtone!=null&&alertRingtone.isPlaying())alertRingtone.stop();
            String saved=getSharedPreferences("man_water",MODE_PRIVATE).getString("alert_uri",null);
            Uri sound=saved==null?RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION):Uri.parse(saved);
            alertRingtone=RingtoneManager.getRingtone(this,sound);
            alertRingtone.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            alertRingtone.play();
            handler.postDelayed(()->{if(alertRingtone!=null&&alertRingtone.isPlaying())alertRingtone.stop();audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION,previous,0);},duration*1000L);
        } catch(Exception error) { audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION,previous,0); }
    }
    private void finishTimer() { handler.removeCallbacks(tick); left=0; notifyNow(); if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release(); stopForeground(STOP_FOREGROUND_DETACH); stopSelf(); }
    private String format(long seconds) { return String.format(Locale.US,"%02d:%02d:%02d",seconds/3600,(seconds%3600)/60,seconds%60); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
