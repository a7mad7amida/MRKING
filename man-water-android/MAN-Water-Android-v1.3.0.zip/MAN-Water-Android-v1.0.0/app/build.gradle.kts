plugins {
    id("com.android.application")
}

android {
    namespace = "ps.man.water"
    compileSdk = 35

    defaultConfig {
        applicationId = "ps.man.water"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "1.3.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
}

dependencies { }
