package ps.man.water
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity:AppCompatActivity(){private lateinit var web:WebView
@SuppressLint("SetJavaScriptEnabled") override fun onCreate(b:Bundle?){super.onCreate(b);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),30);web=WebView(this);setContentView(web);web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.settings.databaseEnabled=true;web.settings.cacheMode=WebSettings.LOAD_DEFAULT;web.addJavascriptInterface(TimerBridge(this),"AndroidTimer");web.webViewClient=object:WebViewClient(){override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest)=if(r.url.host=="man.ps")false else{startActivity(Intent(Intent.ACTION_VIEW,r.url));true}};web.webChromeClient=WebChromeClient();web.loadUrl("https://man.ps/water")}
override fun onBackPressed(){if(web.canGoBack())web.goBack()else super.onBackPressed()}}
class TimerBridge(private val a:Activity){@JavascriptInterface fun start(n:String,s:Int)=send(TimerService.START,n,s);@JavascriptInterface fun pause()=send(TimerService.PAUSE);@JavascriptInterface fun resume()=send(TimerService.RESUME);@JavascriptInterface fun stop()=send(TimerService.STOP);private fun send(x:String,n:String="",s:Int=0){val i=Intent(a,TimerService::class.java).setAction(x).putExtra("name",n).putExtra("seconds",s);if(x==TimerService.START)a.startForegroundService(i)else a.startService(i)}}
